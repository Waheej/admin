globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/66b2c93ea34bb046.js",
      "static/chunks/turbopack-c5a0ca6e6fac8edb.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/66b2c93ea34bb046.js",
      "static/chunks/turbopack-be16da220b1b3a78.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/dcedc9879d54b004.js",
    "static/chunks/2d9285e85aed01d3.js",
    "static/chunks/7880f8283a6f3daf.js",
    "static/chunks/b617aa7ff1279f8a.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-716980441a10c7b1.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];