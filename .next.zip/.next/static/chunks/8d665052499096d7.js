__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/66b2c93ea34bb046.js",
  "static/chunks/turbopack-c5a0ca6e6fac8edb.js"
])
